import discord
from discord.ext import buttons
from random import randint, choice

class Game(buttons.Paginator):
    def __init__(self, member_id, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.member_id = str(member_id)
        self.square_colours = "white_large, orange, blue, red, purple, green, yellow".split(", ")
        self.board_size = [8, 6]
        self.board = []
        for y in range(self.board_size[1]):
            self.board.append(" "*self.board_size[0])
        self.p = [randint(0,len(self.board[0])-1), randint(0,len(self.board)-1)]
        self.line = list(self.board[self.p[1]])
        self.line[self.p[0]] = "O"
        self.board[self.p[1]] = "".join(self.line)

        self.border = ":%s_square:" % choice(self.square_colours)
        self.sent_embed = False

        # self.buttons = {(0, '⬆️'): buttons.button(emoji='⬆️', position=0, callback=lambda: self.move((0,-1))),
        #                 (1, '⬇️'): buttons.button(emoji='⬇️', position=1, callback=lambda: self.move((0,1))),
        #                 (2, '⬅️'): buttons.button(emoji='⬅️', position=2, callback=lambda: self.move((-1,0))),
        #                 (3, '➡️'): buttons.button(emoji='➡️', position=3, callback=lambda: self.move((1,0))),
        #                 (4, '🛑'): buttons.button(emoji='🛑', position=4, callback=self.stop)}

    async def printboard(self, ctx):
        self.print_board = self.board.copy()
        self.print_board.insert(0, self.border*self.board_size[0])
        self.print_board.insert(len(self.print_board)+1, self.border*self.board_size[0])
        for i, row in enumerate(self.print_board):
            self.print_board[i] = self.border+row+self.border
        self.print_board = "\n".join(self.print_board)
        self.print_board = self.print_board.replace(" ", "⬛")
        self.print_board = self.print_board.replace("O", "🤡")
        self.em = discord.Embed(title="Game", description=self.print_board)
        
        if self.sent_embed == False:
            self.game_msg = await ctx.send(embed=self.em)
            self.sent_embed = True
        else:
            await self.game_msg.edit(embed=self.em)
    
    def move(self, x, y):
        self.line = list(self.board[self.p[1]])
        self.line[self.p[0]] = " "
        self.line = "".join(self.line)
        self.board[self.p[1]] = self.line

        self.p[0] += x
        self.p[1] += y

        if self.p[0] < 0: self.p[0] = 0
        if self.p[0] > len(self.board[0])-1: self.p[0] = len(self.board[0])-1
        if self.p[1] < 0: self.p[1] = 0
        if self.p[1] > len(self.board)-1: self.p[1] = len(self.board)-1
        
        self.line = list(self.board[self.p[1]])
        self.line[self.p[0]] = "O"
        self.line = "".join(self.line)
        self.board[self.p[1]] = self.line

    @buttons.button(emoji='⬆️')
    async def up(self, ctx, member):
        self.move(0,-1)
        await self.printboard(ctx)
    @buttons.button(emoji='⬇️')
    async def down(self, ctx, member):
        self.move(0,1)
        await self.printboard(ctx)
    @buttons.button(emoji='⬅️')
    async def left(self, ctx, member):
        self.move(-1,0)
        await self.printboard(ctx)
    @buttons.button(emoji='➡️')
    async def right(self, ctx, member):
        self.move(1,0)
        await self.printboard(ctx)

    @buttons.button(emoji='🛑')
    async def stop(self, ctx, member):
        await self.game_msg.edit(embed=discord.Embed(title="Stopped game."))
        await self.teardown()
        await asyncio.sleep(3)
        await self.game_msg.delete()
        del games[self.member_id]

async def tst(bot):
    guild = bot.get_guild(779288049355194398)
    muted_role = discord.utils.get(guild.roles, id=779289752092409897)
    member_role = discord.utils.get(guild.roles, id=779289515612569622)
    await guild.get_member(810997010429771806).remove_roles(muted_role)
    await guild.get_member(810997010429771806).add_roles(member_role)