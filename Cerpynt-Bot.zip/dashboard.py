from flask import Flask, render_template, url_for
from threading import Thread
import json

app = Flask("")

@app.route('/')
def home():
    with open("punishments.json") as f:
        data = json.load(f)
    return render_template("dashboard.html", data=data)

def run():
    try:
        app.run(host='0.0.0.0',port=8000)
    except: pass

def keep_alive():
    t = Thread(target=run)
    t.start()