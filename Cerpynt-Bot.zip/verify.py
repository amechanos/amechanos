from captcha.image import ImageCaptcha
from os import listdir
import string, random, json

font_path = "./fonts/"
fonts = listdir(font_path)
for i, font in enumerate(fonts):
    fonts[i] = font_path+font

def generate_captcha(member_id):
    image = ImageCaptcha(fonts=fonts)

    random_string = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
    image.write(random_string, "out.png")
    with open("verify.json", "r") as f:
        data = json.load(f)
        if member_id in data:
            data[member_id] = [random_string, data[member_id][1] - 1]
        else:
            data[member_id] = [random_string, 3]
        json.dump(data, open("verify.json", "w"), indent=4, sort_keys=True)
        f.close()