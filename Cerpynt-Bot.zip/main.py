import discord, asyncio, os, json, random, aiohttp, DiscordUtils
from discord.ext import commands
from discord.ext.commands import MissingPermissions
from discord.utils import get
from dashboard import keep_alive
from game import *
from verify import *
from bs4 import BeautifulSoup
from googlesearch import search 

intents = discord.Intents().all()

prefix = "="
bot = commands.Bot(command_prefix=prefix,
                   intents=intents,
                   case_insensitive=True)

audit_logs = [841975573333278721, 862501697698922516]
async def log(ctx, msg=None, embed: discord.Embed=None):
    if msg != None:
        em = discord.Embed(description=str(msg), color=0xff2e2e)
    else:
        em = embed
    if type(ctx) == discord.Member:
        uid = str(ctx.id)
    else:
        uid = str(ctx.message.author.id)

    data = json.load(open("log.json", "r"))
    try:
        log_data = data.copy()
        if uid not in log_data:
            log_data[uid] = [str(msg)]
        else:
            log_data[uid].append(str(msg))
        json.dump(log_data, open("log.json", "w"))
    except Exception as e:
        print(e)
        json.dump(data, open("log.json", "w"))

    for channel_id in audit_logs:
        await bot.get_channel(channel_id).send(embed=em)



async def tasks():
    # on_ready things in here
    await bot.wait_until_ready()

    # removes and adds reaction to verify message so that bot can see if user verifies
    verify_msg = await bot.get_channel(779293613392658432).fetch_message(
        849782495074844692)
    guild = bot.get_guild(779288049355194398)
    member = await guild.fetch_member(734915838695440474)
    try:
        await verify_msg.remove_reaction("✅", member)  # bot.user
    except:
        pass
    await verify_msg.add_reaction("✅")

    print('Logged in as: Admin \n ID: 4206980085')
    print('---------------------------------------')
    print('Bot is now online.')

    await tst(bot)

    statuses = [
        "watching over phoenixes and serpents",
        "a masked man and a snake build me", "sub to snek", "sub to jxsn",
        "watching for %shelp" % prefix,
        "Fighting fire with fire and water with water",
        "Ready to catch untamed beasts", "Watching over the archaeologists",
        "with fire and water", "in the deep ocean, diving",
        "in the sky, flying", "catching bad archaeologists",
        "hunting mythical creatures", "finding fantastic beasts"
    ]

    tick = 0
    while True:
        if tick % 5 == 0:
            status = random.choice(statuses)
            if status.startswith("watching"):
                await bot.change_presence(activity=discord.Activity(
                    type=discord.ActivityType.watching,
                    name=status.strip("watching ")))
            else:
                await bot.change_presence(activity=discord.Game(name=status))

        del_ask_cooldown = []  # ask cooldown
        for key in ask_cooldown.keys():
            if ask_cooldown[key] <= 0:
                del_ask_cooldown.append(key)
            else:
                ask_cooldown[key] -= 1
        for key in del_ask_cooldown:
            del ask_cooldown[key]

        await asyncio.sleep(1)
        tick += 1


@bot.event
async def on_message_delete(message):
    global sma, smc
    if str(message.channel.id) in sma:
        sma[str(message.channel.id)].append(message.author)
    else:
        sma[str(message.channel.id)] = [message.author]

    if str(message.channel.id) in smc:
        smc[str(message.channel.id)].append(message.content)
    else:
        smc[str(message.channel.id)] = [message.content]

    await asyncio.sleep(3600)  # resets after an hour
    smc[str(message.channel.id)].remove(message.content)
    sma[str(message.channel.id)].remove(message.author)


@bot.event
async def on_member_join(member):
    guild = bot.get_guild(779288049355194398)
    await bot.get_channel(849773069705805874).send(
        f"Welcome {member.mention}, you are member No. {len(guild.members)} ! Please go to <#779290325007990805> to get your roles and <#779293613392658432> to see the full rules! If you need help, don't hesitate to read the FAQ channel or to simply do %sask in the channel <#845185610612473896> \n\n **Make sure to go to <#779293613392658432> to verify!**"
        % prefix)
    await captcha(member)
    roles = member.roles
    join = discord.Embed(title=member.name + "#" + member.discriminator, description=member.mention, colour=member.colour, timestamp=ctx.message.created_at)
    join.add_field(name='ID:', value=member.id, inline=False)
    join.add_field(name="Created Account On:", value=member.created_at.strftime("%a, %#d %B %Y, %I:%M %p UTC"), inline=False)
    join.add_field(name="Joined Server On:", value=member.joined_at.strftime("%a, %#d %B %Y, %I:%M %p UTC"), inline=False)
    join.add_field(name='Discriminator:', value=member.discriminator)
    join.set_author(name=member.name, icon_url=member.avatar_url)
    
    await log(ctx, embed=join)

    

@bot.event
async def on_raw_reaction_add(payload):
    if payload.user_id == 734915838695440474:
        return  # if user is bot then return

    if payload.channel_id == 779293613392658432:
        if payload.emoji.name == "✅":
            guild = bot.get_guild(
                payload.guild_id
            )  # do you want the reaction to be removed once the person verifies?
            verified = discord.utils.get(guild.roles, id=779289515612569622)
            if verified not in payload.member.roles:
                await payload.member.add_roles(verified)


@bot.event
async def on_member_remove(member):
    await bot.get_channel(849773069705805874).send(f"{ctx.member.mention} left the server")
    await log(member, str(member)+"left the server")


badwords = ['fuck', 'fuk', 'fuc', 'porn', 'purn', 'bitch', 'bitc', 'bich']


def has_profanities(content):
    splitters = " ._/?|][}{)(*&^%$#@!-+=`~<>"
    for i in badwords:  # Go through the list of bad words;
        if i.lower() in content.lower():
            return True
        for splitter in splitters:
            if i in "".join(content.lower().split(splitter)):
                return True
    return False

gn = ["sleep", "head off tonight", "go to bed" ]

@bot.event
async def on_message(message):
    try:
        if message.channel.category_id is not None:
            if message.channel.category_id in [
                779288049867554847, 845152447461982210
            ]:
                if has_profanities(message.content):
                    await message.delete()
                    msg = await message.channel.send(
                        f"{message.author.mention} Please don't swear in the main channels, you can do it in the catergory fun.")
                    await asyncio.sleep(3)
                    await msg.delete()
    except: pass

    if message.author.id == 734915838695440474:
        return
    else:
        message.content.lower()
        if  message.content.split() in ('sleep', 'go to bed'):
            sleep=discord.Embed(title=f"Sleep Tight {message.author}!", description=f"Goodnight {message.author} have a good one. :wave: ")
            sleep.set_footer(value="Sweet dreams." + member.avatar_url)
    
            msg = await message.channel.send(embed=sleep)
        else: return

    # youtube notify
    if message.channel.id == 845171086261747752:  
        if message.author.id == 204255221017214977:  # yagpdb (bot) id
            if " uploaded a new youtube video!" in message.content:
                await message.delete()
                await message.channel.send("||<@&845650524253978645>||\n" + message.content)
                

    if "@everyone" in message.content:
        with open("everyone.json", "r") as f:
            data = json.load(f)
            if str(message.author.id) not in data: 
                data[str(message.author.id)] = 2
                json.dump(data, open("everyone.json", "w"))
                await asyncio.sleep(3600)
                data[str(message.author.id)] += 1
                json.dump(data, open("everyone.json", "w"))
            else:
                data[str(message.author.id)] -= 1
                json.dump(data, open("everyone.json", "w"))
                await asyncio.sleep(3600)
                data[str(message.author.id)] += 1
                json.dump(data, open("everyone.json", "w"))
            if data[str(message.author.id)] <= 0:
                data.pop(str(message.author.id), None)
                json.dump(data, open("everyone.json", "w"))
                await message.channel.send("%s has pinged everyone 3 times in an hour. They have been muted for 10 minutes." % message.author.mention)
                
                guild = message.guild
                muted_role = discord.utils.get(guild.roles, id=779289752092409897)
                member_role = discord.utils.get(guild.roles, id=779289515612569622)
                await message.author.add_roles(muted_role)
                await message.author.remove_roles(member_role)
                await asyncio.sleep(600)
                await message.author.remove_roles(muted_role)
                await message.author.add_roles(member_role)
                
    await bot.process_commands(message)



@bot.command(name="badwords")
async def bwlist(ctx):
    em = discord.Embed(title="Badwords List")
    em.color = 0x1abc9c
    em.add_field(name="Messages with these words will be deleted", value="\n".join(badwords))
    em.set_footer(text="The bot is smart enough to identify badwords with symbols that split it.")
    await ctx.send(embed=em)




#       ▼ ▼ ▼ GENERAL COMMANDS ▼ ▼ ▼
@bot.command()
async def origin(ctx):
    em = discord.Embed(title="Origins")
    em.color = 0x1abc9c
    em.add_field(
        name="***-- CERPYNT CLAN --***",
        value=
        "I watched the world split. Mass destruction overloaded this world of greatness. Land flew into the air, and mountains floated into space.  Upon this, a white light blinded the world, with a single soul to fill. That was me. This was a one in a trillion chance. It gave me power. I felt it. I could not control it and my elements burst out, ready for recapturing by great people with great talent. This was all in another universe. The elements traveled to some unknown land. Now my power is controlled by what is known as the new eSports team, with one goal, to get game domination."
    )
    em.add_field(
        name="***-- ASIAN GANG --***",
        value=
        "There was impending doom approaching. Then, fire emerged, destroying our village. Then we flew into space, traveling through a black hole to an unknown land, which we now know is Asia. We landed right in the ocean, with a small island to work with. We needed a proper team to build a new village. And to build a new future, dominating games."
    )
    await ctx.send(embed=em)


#punishments
@bot.command()
async def punish(ctx):
    em = discord.Embed(title="PUNISHMENTS",  inline=False)
    em.color = 0x1abc9c
    em.add_field(name="**5 Warnings**",value= "- Temp Mute for 5 minutes\n - Talk with a staff member (depends on how bad it is)", inline=False)
    em.add_field(name="**10 Warnings**", value="- Temp mute for 1 hour\n - Talk with a staff member")
    em.add_field(name="**20 warnings**", value="- Kick",  inline=False)
    em.add_field(name="**5 Warnings after kick rejoin**", value="- Temp ban for a week",  inline=False)
    em.add_field(name="**5 Warnings after Temp Ban**", value="- Perm ban",  inline=False)
    em.set_footer(
        text="To check how many warnings you have, simple do `=dashboard`")
    await ctx.send(embed=em)




smc = {}
sma = {}


@bot.command()
async def snipe(ctx):
    if str(ctx.channel.id) not in smc:
        await ctx.channel.send("Theres nothing to snipe.")
        return

    embed = discord.Embed(
        description="{}".format(smc[str(ctx.channel.id)][-1]))
    embed.set_footer(text="Sent by %s" % sma[str(ctx.channel.id)][-1],
                     icon_url=sma[str(ctx.channel.id)][-1].avatar_url)
    embed.color = 0x1abc9c
    await ctx.channel.send(embed=embed)
    return


@bot.command()  #   sniping the list of all messages deleted in the past hour, only for admins to see who is ghost pinging, etc.
async def listsnipe(ctx):
    if ctx.message.author.guild_permissions.manage_messages:
        if str(ctx.channel.id) not in smc:
            await ctx.channel.send("Theres nothing to snipe.")
            return

        embed = discord.Embed()
        embed.color = 0x1abc9c
        max_length = 5
        if len(smc[str(ctx.channel.id)]) <= max_length:
            snipe_list = smc[str(ctx.channel.id)]
        else:
            snipe_list = smc[str(ctx.channel.id)][:max_length]
        for i, x in enumerate(snipe_list):
            if len(ctx.message.embeds) > 0:
                embed.add_field(name="Sent by %s" %
                                sma[str(ctx.channel.id)][i],
                                value="Embed Object",
                                inline=False)
            else:
                embed.add_field(name="Sent by %s" %
                                sma[str(ctx.channel.id)][i],
                                value=x,
                                inline=False)

        embed.set_footer(
            text="In order of earliest to latest deleted messages.")
        await ctx.send(embed=embed)
        return


with open("members.json", "r") as f:
    members = json.load(f)
    f.close()


@bot.command()
async def bio(ctx, member=None):
    em = discord.Embed()
    em.color = 0x1abc9c
    if member == None:
        em.title = "Use %sbio <member> to look at their bio!" % prefix
        em.description = "Cerpynt Clan & Asian Gang Members"
        for clan in members:
            em.add_field(name="**%s**:" % clan,
                         value=", ".join(members[clan].keys()))
        await ctx.send(embed=em)
        return

    all_members = members["Cerpynt Clan"].copy()
    all_members.update(members["Asian Gang"])

    m = member.lower()
    for x in all_members:
        if m == x:
            em.title = x.title()
            em.description = all_members[x]
            break

    try:
        await ctx.send(embed=em)
    except:
        await ctx.send("Member not found.. check the member list with %sbio" %
                       prefix)


@bot.command(description="cool")
async def dashboard(ctx):
    await ctx.send("https://Cerpynt-Bot.extremsnek.repl.co")


ask_cooldown = {}


@bot.command(description="ask")
async def ask(ctx, clan, *suggestion):
    if clan.lower() in "cp":
        clan_ping = 799152820833091594
    elif clan.lower() in "ag":
        clan_ping = 829213439779274782
    else:
        return

    if str(ctx.message.author.id) not in ask_cooldown:
        await ctx.send(f'<@&%s>, {ctx.message.author.mention} asks: "%s"' %
                       (str(clan_ping), " ".join(suggestion)))
        ask_cooldown[str(ctx.message.author.id)] = 30
    else:
        msg = await ctx.send(
            f"{ctx.message.author.mention}, you must wait another %s seconds to ask again." %
            str(ask_cooldown[str(ctx.message.author.id)]))
        await asyncio.sleep(4)
        await msg.delete()

bot.remove_command("help")
@bot.command()
async def help(ctx):
    contents = [

    "**All Commands** \n General Commands: Daily use all-around commands. \n Fun: Multupurpose fun commands that are enjoyable. \n Moderation: What them mods can do.",
    
    "**General:** \n help: Pulls up this help message. \n origin: The origins of Cerpynt Clan and Asian gang summarised in two paragraphs. \n bio `<member>`: Look at the biographies written by members of both Cerpynt Clan and Asian Gang. Leave `<member>` blank to view all members. \n snipe: Get the last deleted message.\n dashboard: Opens up the dashoard that shows mutes, warns and etc. \n punish: Opens up the punishments you can get from the amount of warns you have. \n badwords: Sends the list of badwords that are removed in chat.",
   
    "**Fun:** \n coinflip: Flips a coin \n 8ball: Ask a question and the bot will answer as truthfully as it can \n game: Creates a game to be controlled by reaction controls. Currently work in progress. \n read: Reads a passage/precept from the holy '57 Precepts of Z.O.T.E' from Hollow Knight. Add a number `<precept no>` to read that specific one.", 
     
    "**Moderator:** \n warn `<member>` `[reason]`: Warn a member for any wrongdoings. <member> is a mention of the member in the server, [reason] is optional but can be used to say what the member did wrong. \n warns `<command>` `[member]`: List of commands for <command>: *reset*. [member] is the user that the command is being used on. \n mute `<command>` `[member]`: Mutes a member. Revokes the permission to talk or join in channels \n unmute `<command>` `[member]`: Unmutes a member. Allows members to talk/join channel again \n tempmute `<command>` `[member]`: Temporarily mutes a user. \n kick `<command>` `[member]`: Kicks a member from the server. Dont forget to mention the user `<user>` \n ban `<command>` `[member]`: Bans a member from the server. Beware of using this command \n unban `<command>` `[member]`: Unbans a member from the server. Requires getting user ID. (Using dev mode, right click on user) \n tempban `<command>` `[member]`: Temporarily bans a member.  \n clear `<command>` `[amount]`: Clears unwanted messages. If the amiunt is undefined, the previous message will get deleted"
    ]

    embeds = []
    for i, content in enumerate(contents):
        split_content = content.split(" \n ")
        title = split_content[0]
        embed = discord.Embed(title=title, inline=True)
        embed.color= 0x1abc9c
        for command in split_content[1:]:
            command_content = command.split(": ")
            embed.add_field(name=command_content[0], value=command_content[1])
        embed.set_footer(text="Page %s/%s. Made by jxsn and snek" % (str(i+1), str(len(contents))) )
        embeds.append(embed)

    # discord.utils paginator (simple way to use reaction thing)
    paginator = DiscordUtils.Pagination.CustomEmbedPaginator(ctx, remove_reactions=True)
    paginator.add_reaction('⬅️', "back")
    paginator.add_reaction('➡️', "next")
    await paginator.run(embeds)

#====================================================================== games command
games = {}

@bot.command()
async def game(ctx):
    if str(ctx.message.author.id) not in games.keys():
        games[str(ctx.message.author.id)] = Game(
            ctx.message.author.id,
            title='Move the Clown',
            colour=0xc67862,
            embed=True,
            use_defaults=False,
            entries=[
                "**Freely move the clown to your liking!**\n\nNote: This command is currently still work in progress so don't expect this to be any fun at this stage."
            ],
            length=1,
            timeout=90.0)
        await games[str(ctx.message.author.id)].start(ctx)
        await games[str(ctx.message.author.id)].printboard(ctx)
    else:
        await ctx.send(
            "You already have a game running. Stop your previous game to start a new one."
        )

# @bot.command()
# async def image(ctx, *, query):
#     author = ctx.author.mention
#     async with ctx.typing(): 
#         await ctx.channel.send(f"Here are the links related to your question {author} !") 
#         await ctx.send(f"\n:point_right: {j}") 
        
    




#======================================================================= MOD commands

@bot.command()
async def checkwarns(ctx, member):
    warnings = json.load(open("punishments.json", "r"))["warnings"]
    if warnings[str(member.id)][1] == 5:
        guild = ctx.guild
        muted_role = discord.utils.get(guild.roles, id=779289752092409897)
        member_role = discord.utils.get(guild.roles, id=779289515612569622)

        if not muted_role:
            mutedRole = await guild.create_role(name="Muted")
            for channel in guild.channels:
                await channel.set_permissions(mutedRole,
                                              speak=False,
                                              send_messages=False,
                                              read_message_history=True,
                                              read_messages=False)
        await member.add_roles(muted_role)
        await member.remove_roles(member_role)
        await asyncio.sleep(300)
        await member.add_roles(member_role)
        await member.remove_role(muted_role)
        await log(ctx, 
            f"{ctx.user.mention} has gotten 5 warnings resulting in a 5 minute mute."
        )
        return

    elif warnings[str(member.id)][1] == 10:
        guild = ctx.guild
        muted_role = discord.utils.get(guild.roles, id=779289752092409897)
        member_role = discord.utils.get(guild.roles, id=779289515612569622)
        if not muted_role:
            mutedRole = await guild.create_role(name="muted")
            for channel in guild.channels:
                await channel.set_permissions(mutedRole,
                                              speak=False,
                                              send_messages=False,
                                              read_message_history=True,
                                              read_messages=False)
        await member.add_roles(muted_role)
        await member.remove_roles(member_role)
        await log(ctx, 
            f"{ctx.user.mention} has gotten 10 warnings, resulting in a 1 hour mute."
        )
        await asyncio.sleep(3600)
        await member.add_roles(member_role)
        await member.remove_role(muted_role)
        await log(ctx, 
            f"{ctx.user.mention}'s 1 hour mute has passed, they may now speak."
        )

    elif warnings[str(member.id)][1] == 20:
        await member.kick()
        await ctx.get_channel(audit_logs).send(
            f"{ctx.user.mention}has gotten 20 warnings. They have been kicked."
        )


with open("punishments.json", "r") as f:
    main_json = json.load(f)
    warnings = main_json["warnings"]
    f.close()


def member_has_role(member, role_id):
    for role in member.roles:
        if role.id == role_id:
            return True
    return False


# @bot.command()
# async def warn(ctx, member: discord.Member, *reason):
#     if not (member_has_role(ctx.author, 799152820833091594)
#             or member_has_role(ctx.author, 829213439779274782)):
#         return  # if user has neptune or fire roles then run command

#     if ctx.author == member:
#         await ctx.send("You can't warn yourself nerd")
#         return
#     if str(member.id) not in warnings.keys():
#         warnings[str(member.id)] = [str(member), 1]
#     else:
#         warnings[str(member.id)][1] += 1
#     em = discord.Embed()
#     if len(reason) == 0:
#         em.title = "User has been warned!"
#         await log(ctx, 
#             f"{member.mention} has been warned. ")
#     else:
#         em.title = "User has been warned for " + " ".join(reason)
#         try:
#             await member.send("You have been warned for %s in Cerpynt Clan." % " ".join(reason))
#         except: await ctx.send("Could not message user..")
#         await log(ctx, 
#             f"{member.mention} has been warned for " + " ".join(reason))
#     em.description = "%s has %s warnings now." % (member.mention, warnings[str(
#         member.id)][1])
#     await ctx.send(embed=em)

#     with open("punishments.json", "w") as f:
#         main_json["warnings"] = warnings
#         json.dump(main_json, f, indent=4, sort_keys=True)
#         f.close()


@bot.command(aliases=["warnings", "warning"])
@commands.has_permissions(kick_members=True, ban_members=True)
async def warns(ctx, func=None, m=None):
    global warnings
    if not (member_has_role(ctx.author, 799152820833091594)
            or member_has_role(ctx.author, 829213439779274782)):
        return  # if user has neptune or fire roles then run command

    if func == None:
        await ctx.send(
            "No command mentioned, check %shelp moderator to view list of functions."
            % prefix)
        return

    if func == "reset":
        if m == None:
            await ctx.send("No member mentioned. @ someone after the command")
            return
        try:
            member = m[3:-1]
            guild = bot.get_guild(779288049355194398)
            member = guild.get_member(int(member))
        except:
            await ctx.send("Could not warn member.. Maybe it is wrong?")
            return
        if str(member.id) not in warnings.keys():
            await ctx.send("Member already has no warnings.")
            return
        msg = await ctx.send(
            "Are you sure you want to reset the warnings of %s?" %
            member.display_name)
        await msg.add_reaction('✅')

        def check(reaction, user):
            return user == ctx.message.author and str(
                reaction.emoji) == '✅' and reaction.message == msg

        try:
            reaction, user = await bot.wait_for("reaction_add",
                                                timeout=5.0,
                                                check=check)
        except asyncio.TimeoutError:
            await ctx.send("Waited too long to react.")
        else:
            with open("punishments.json", "r") as f:
                main_json = json.load(f)
                return_warnings = main_json["warnings"]
                del return_warnings[str(member.id)]
                main_json["warnings"] = return_warnings
                json.dump(main_json,
                          open("punishments.json", "w"),
                          indent=4,
                          sort_keys=True)
                warnings = return_warnings
                f.close()
            await ctx.send("Successfully removed the warnings of %s!" %
                           member.display_name)
            await log(ctx, 
                f"{member.mention}'s warnings has been reset.")
        await msg.delete()




@bot.command(description="Kicks a member")
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *reason):
    if member.guild_permissions.manage_server:
        await ctx.send(f"{member.mention} is a mod, so you cannot kick them.")
        return

    if reason == None:
        await ctx.send(f"{member} was kicked.")
        await member.send("You were kicked From Cerpynt clan.")
        await log(ctx, 
            f"{member.mention} has been kicked by {ctx.author.mention}")
    else:
        await ctx.send(f"{member} was kicked for %s" % " ".join(reason))
        await member.send("You were kicked From Cerpynt clan for %s" %
                          " ".join(reason))
        await log(ctx, 
            f"{member.mention} has been kicked by {ctx.author.mention} for " +
            " ".join(reason))
    await member.kick(reason=" ".join(reason))

    with open("punishments.json", "r") as f:
        main_json = json.load(f)
        kicks = main_json["kicks"]
        if str(member.id) not in kicks.keys():
            kicks[str(member.id)] = [str(member), 1]
        else:
            kicks[str(member.id)][1] += 1
        main_json["kicks"] = kicks
        json.dump(main_json,
                  open("punishments.json", "w"),
                  indent=4,
                  sort_keys=True)
        f.close()


@bot.command(description="Bans a member")
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason=None):
    if member.guild_permissions.ban_members:
        await ctx.send(f"{member.mention} is a mod, so you cannot ban them.")
        return

    try:
        await member.ban(reason=reason)
        await ctx.send(f"{member} was banned!")
        await log(ctx, 
            f"{member.mention} has been banned by {ctx.author.mention}.")

        with open("punishments.json", "r") as f:
            main_json = json.load(f)
            bans = main_json["bans"]
            if str(member.id) not in bans.keys():
                bans[str(member.id)] = [str(member), 1]
            else:
                bans[str(member.id)][1] += 1
            main_json["bans"] = bans
            json.dump(main_json,
                      open("punishments.json", "w"),
                      indent=4,
                      sort_keys=True)
            f.close()
    except:
        await ctx.send("The user could not be found.")


@bot.command(description="Unbans a member")
@commands.has_permissions(ban_members=True)
async def unban(ctx, member):
    bannedUsers = await ctx.guild.bans()
    name, discriminator = member.split("#")
    for ban in bannedUsers:
        user = ban.user
        if (user.name, ser.discriminator) == (name, discriminator):
            await ctx.guild.unban(user)
            await ctx.send(f"{user.mention} was unbanned.")
            await log(ctx, 
                f"{member.mention} has been unbanned by {ctx.message.author.mention}."
            )

        return


@bot.command(description="Mutes the specified user.")
@commands.has_permissions(manage_guild=True)
async def mute(ctx, member: discord.Member, *reason):
    if member.guild_permissions.manage_messages:
        await ctx.send(f"{member.mention} is a mod, so you cannot mute them.")
        return

    guild = ctx.guild
    muted_role = discord.utils.get(guild.roles, id=779289752092409897)
    member_role = discord.utils.get(guild.roles, id=779289515612569622)

    if not muted_role:
        mutedRole = await guild.create_role(name="Muted")
        for channel in guild.channels:
            await channel.set_permissions(mutedRole,
                                          speak=False,
                                          send_messages=False,
                                          read_message_history=True,
                                          read_messages=False)
    if ctx.message.author == discord.Member:
        await ctx.send("You cannot mute yourself nerd")

    try:
        await member.add_roles(muted_role, reason=reason)
        await member.remove_roles(member_role)
        if len(reason):
            await ctx.send(f"{ctx.message.author} muted {member.mention}." %
                           " ".join(reason))
            await log(ctx, 
                f"{ctx.member.mention} has been muted by {ctx.author.mention}")
        else:
            await ctx.send(
                f"{ctx.message.author} muted {member.mention} because: " +
                " ".join(reason))
            await log(ctx, 
                f"{ctx.member.mention} has been muted by {ctx.author.mention} for "
                + " ".join(reason))
        return
    except:
        await ctx.send("You did not provide a user, try again.")


@bot.command(description="Unmutes a specified user.")
@commands.has_permissions(manage_guild=True)
async def unmute(ctx, member: discord.Member):
    guild = ctx.guild
    muted_role = discord.utils.get(guild.roles, id=779289752092409897)
    member_role = discord.utils.get(guild.roles, id=779289515612569622)
    await member.remove_roles(muted_role)
    await member.add_roles(member_role)
    await ctx.send(f"{ctx.message.author} unmuted {member.mention}")
    await log(ctx, 
        f"{member.mention} has been unmuted by {ctx.message.author.mention}.")


@bot.command(description="Clears unwanted message(s)")
@commands.has_permissions(manage_messages=True) 
async def clear(ctx, limit=2):
    if 0 < int(limit) < 1000:
        with ctx.channel.typing():
            deleted = await ctx.channel.purge(limit=int(limit) + 1)
            msg = await ctx.send(f"Deleted {len(deleted)-1:,} messages.\n Requested by {ctx.message.author}", delete_after=5)
            await asyncio.sleep(4)
            await msg.delete()
    else:
        await ctx.send("The value you provided is greater than I can handle.")



def is_mod(member):
    mod_roles = []
    #           fire apprentice    neptunes assitant   poseiden (admin)
    for x in [829213439779274782, 799152820833091594, 779455279325773835]:
        discord.utils.get(bot.get_guild(779288049355194398).roles, id=x)

    for role in mod_roles:
        if role in member.roles:
            return True
    return False


@bot.command(description="Temporarily mutes one")
@commands.has_permissions(manage_guild=True)
async def tempmute(ctx, member: discord.Member, limit="5m"):
    if member.guild_permissions.manage_messages:
        if ctx.message.author.id != 810997010429771806:
            await ctx.send(
                f"{member.mention} is a mod, so you cannot mute them.")
            return

    # if not is_mod(member):
    #     await ctx.send("You do not have perms")
    #     return

    intlimit = 0
    for x in limit.lower().split():
        if "s" in x:
            intlimit += int(x[:-1])
        elif "m" in x:
            intlimit += int(x[:-1]) * 60
        elif "h" in x:
            intlimit += int(x[:-1]) * 60 * 60
        elif "d" in x:
            intlimit += int(x[:-1]) * 60 * 60 * 24
        else:
            intlimit += int(x)

    guild = ctx.guild
    muted_role = discord.utils.get(guild.roles, id=779289752092409897)
    member_role = discord.utils.get(guild.roles, id=779289515612569622)
    if intlimit >= 10 and intlimit <= 86400:
        if ctx.message.author == member:
            await ctx.send("You cannot mute yourself nerd")

        await member.add_roles(muted_role)
        await member.remove_roles(member_role)
        # if len(reason) == 0:
        await ctx.send(f"{ctx.message.author} muted {member.mention} for %s" %
                       limit)
        await log(ctx, 
            f"{member.mention} has been muted by {ctx.message.author} for " +
            limit)
        # else:
        #     await ctx.send(
        #         f"{ctx.message.author} muted {member.mention} for %s because: %s"
        #         % (limit, " ".join(reason)))
        #     await log(ctx, f"{member.mention} has been muted by {ctx.message.author} for "+" ".join(reason)+(limit))
        with open("punishments.json", "r") as f:  # add to json
            main_json = json.load(f)
            mutes = main_json["mutes"]
            if str(member.id) not in mutes.keys():
                mutes[str(member.id)] = [str(member), 1]
            else:
                mutes[str(member.id)][1] += 1
            main_json["mutes"] = mutes
            json.dump(main_json,
                      open("punishments.json", "w"),
                      indent=4,
                      sort_keys=True)
            f.close()
        await asyncio.sleep(intlimit)
        await member.remove_roles(muted_role)
        await member.add_roles(member_role)
        await ctx.send(f"{member.mention} Your mute is over. You may now talk."
                       )
        await log(ctx, 
            f"{member.mention}'s mute is now over.")
        # with open("punishments.json", "r") as f: # uncomment to remove from punishments when added.
        #     main_json = json.load(f)
        #     mutes = main_json["mutes"]
        #     if str(member.id) not in mutes.keys():
        #         await ctx.send(f"{member.mention} has no mutes.")
        #         f.close()
        #         return
        #     else:
        #         if mutes[str(member.id)][1] == 1:
        #             del mutes[str(member.id)]
        #         else:
        #             mutes[str(member.id)][1] -= 1
        #     main_json["mutes"] = mutes
        #     json.dump(main_json, open("punishments.json", "w"), indent=4, sort_keys=True)
        #     f.close()
    else:
        if intlimit < 10:
            await ctx.send(str(intlimit))
            await ctx.send("You cannot mute a user for less than a minute")
        elif intlimit > 86400:
            await ctx.send(str(intlimit))
            await ctx.send("You cannot mute a user for more than 1 day")
        else:
            await ctx.send("Something went wrong. Ping moderators for a fix.")


@bot.command(description="Temporarily bans a user")
@commands.has_permissions(ban_members=True)
async def tempban(ctx, member, limit="5m", reason=None):
    if member.guild_permissions.manage_messages:
        await ctx.send(f"{member.mention} is a mod, so you cannot ban them.")
        return

    intlimit = 0
    for x in limit.lower().split():
        if "s" in x:
            intlimit += int(x[:-1])
        elif "m" in x:
            intlimit += int(x[:-1]) * 60
        elif "h" in x:
            intlimit += int(x[:-1]) * 60 * 60
        elif "d" in x:
            intlimit += int(x[:-1]) * 60 * 60 * 24
        if ctx.message.author == discord.Member:
            await ctx.send("You cannot ban yourself nerd")
            try:
                await member.ban(reason=reason)
                if reason == None:
                    await ctx.send(
                        f"{ctx.message.author} banned {member.mention} for %s"
                        % limit)
                else:
                    await ctx.send(
                        f"{ctx.message.author} banned {member.mention} because: %s for %s"
                        % (reason, limit))
                    return
            except Exception as e:
                await ctx.send(e)  # "You did not provide a user, try again."
        elif intlimit < 60:
            await ctx.send("You cannot ban a user for less than a minute")


@bot.command()
@commands.has_permissions(administrator=True)
async def modmute(ctx, member: discord.Member, limit="5m"):
    if not member.guild_permissions.administrator:
        await ctx.send(f"{member.mention} is not a mod.")
        return

    intlimit = 0
    for x in limit.lower().split():
        if "s" in x:
            intlimit += int(x[:-1])
        elif "m" in x:
            intlimit += int(x[:-1]) * 60
        elif "h" in x:
            intlimit += int(x[:-1]) * 60 * 60
        elif "d" in x:
            intlimit += int(x[:-1]) * 60 * 60 * 24
        else:
            intlimit += int(x)

    guild = ctx.guild
    muted_role = discord.utils.get(guild.roles, id=779289752092409897)
    member_role = discord.utils.get(guild.roles, id=779289515612569622)
    admin = {
        "mod": discord.utils.get(guild.roles, id=860134297965297686),
        "ag": discord.utils.get(guild.roles, id=860517127076839445),
        "leader": discord.utils.get(guild.roles, id=799152820833091594),
        
    }
    if intlimit >= 10 and intlimit <= 86400:
        if ctx.message.author == member:
            await ctx.send("You cannot mod mute yourself nerd")
            return

        await member.add_roles(muted_role)
        await member.remove_roles(member_role)
        for role in admin.keys():
            if admin[role] in member.roles:
                admin_role = admin[role]

        await member.remove_roles(admin_role)
        # if len(reason) == 0:
        await ctx.send(f"{ctx.message.author} mod muted {member.mention} for %s" %
                       limit)
        await log(ctx, 
            f"{member.mention} has been mod muted by {ctx.message.author} for " +
            limit)
        # else:
        #     await ctx.send(
        #         f"{ctx.message.author} muted {member.mention} for %s because: %s"
        #         % (limit, " ".join(reason)))
        #     await log(ctx, f"{member.mention} has been muted by {ctx.message.author} for "+" ".join(reason)+(limit))
        with open("punishments.json", "r") as f:  # add to json
            main_json = json.load(f)
            mutes = main_json["mutes"]
            if str(member.id) not in mutes.keys():
                mutes[str(member.id)] = [str(member), 1]
            else:
                mutes[str(member.id)][1] += 1
            main_json["mutes"] = mutes
            json.dump(main_json,
                      open("punishments.json", "w"),
                      indent=4,
                      sort_keys=True)
            f.close()
        await asyncio.sleep(intlimit)
        await member.remove_roles(muted_role)
        await member.add_roles(member_role)
        await member.add_roles(admin_role)
        await ctx.send(
            f"{member.mention} Your mod mute is over. You have been unmuted and your mod permissions are back."
        )
        await log(ctx, 
            f"{member.mention}'s mod mute is now over.")
    else:
        if intlimit < 10:
            await ctx.send(str(intlimit))
            await ctx.send("You cannot mute a user for less than a minute")
        elif intlimit > 86400:
            await ctx.send(str(intlimit))
            await ctx.send("You cannot mute a user for more than 1 day")
        else:
            await ctx.send("Something went wrong. Ping moderators for a fix.")




@bot.command()
@commands.has_permissions(administrator=True)
async def unmodmute(ctx, member: discord.Member, role="cpadmin"):
    if member.guild_permissions.administrator:
        await ctx.send(f"{member.mention} is already a mod.")
        return

    guild = ctx.guild
    muted_role = discord.utils.get(guild.roles, id=779289752092409897)
    member_role = discord.utils.get(guild.roles, id=779289515612569622)
    if ctx.message.author == member:
        await ctx.send("You cannot un-mod-mute yourself nerd")
        return
        
    await member.remove_roles(muted_role)
    await member.add_roles(member_role)
    await member.add_roles(admin_role)
    await ctx.send(
        f"{member.mention} Your mod mute is over. You have been unmuted and your mod permissions are back.")

    
    await log(ctx, f"{member.mention} has been un-mod-muted.")

# async def captcha(m):
#     if str(m.id) in json.load(open("verify.json", "r")):
#         if json.load(open("verify.json", "r"))[str(m.id)][1] <= 0:
#             await m.send("You have no more tries to join Cerpynt Clan.")
#             return

#     generate_captcha(str(m.id))
#     embed = discord.Embed(
#         title="Captcha Verification for Cerpynt Clan",
#         description=
#         "Please type what you see in the image to prove you are human.",
#         color=0x00ff00)  #creates embed
#     file = discord.File("./out.png", filename="image.png")
#     embed.set_image(url="attachment://image.png")
#     await m.send(file=file, embed=embed)

#     def check(msg):
#         return m == msg.author and len(msg.content) == 4

#     data = json.load(open("verify.json", "r"))
#     try:
#         msg = await bot.wait_for('message', check=check, timeout=60.0)
#     except asyncio.TimeoutError:  # after one min of waiting for a reply to the captcha it will kick the user.
#         if data[str(m.id)][1] > 0:
#             await m.send(
#                 "You took too long to verify, and therefore have been kicked. To try again, join the Cerpynt Clan discord server."
#             )
#             await m.kick(reason="User took too long to verify.")

#     if "".join(msg.content).upper() == data[str(msg.author.id)][0]:
#         await msg.channel.send(
#             "Captcha answered successfully! You have joined Cerpynt Clan.")
#         data.pop(str(m.id), None)
#     else:
#         if data[str(msg.author.id)][1] <= 0:
#             await msg.channel.send(
#                 "Captcha was answered incorrectly. You have no more tries and you have been banned from Cerpynt Clan. **If you think this is injust, please contact the server moderators, <@481752330409345026> and <@810997010429771806>.**"
#             )
#             await m.ban(reason="Member ran out of tries to join Cerpynt Clan.")
#             return
#         await msg.channel.send(
#             "Captcha was answered incorrectly. You have %s more tries to answer otherwise you will be banned. **Note: If you are sight impaired and cannot get the captcha right, please contact the server moderators, <@481752330409345026> and <@810997010429771806>.**"
#             % str(data[str(msg.author.id)][1]))
#         await captcha(m)





@bot.command(name="restart", aliases=["r", "kill"])
async def _restart(ctx):            # ids:     snek                jxsn
    if ctx.message.author.id not in [810997010429771806, 481752330409345026]:
        return
    
    await ctx.send(embed=discord.Embed(description="Bot has been restarted."))
    await bot.close()
    os.system("python main.py")






# mod commands end




@bot.command()
async def test(ctx, *message):
    # msg = await bot.get_channel(840463169369014290).fetch_message(861225167199928320)
    # await ctx.send("||<@&845650524253978645>||\n"+msg.content)

    msg = await ctx.send(" ".join(message))
    await msg.edit(content="\u202b" + msg.content)



@bot.command()
async def read(ctx, n=None):
    with open("bible/readings.txt", "r") as f:
        bible = f.readlines()

        if n == None:
            paragraph = random.choice(bible)
        else:
            if int(n)-1 < 0:
                await ctx.send("Number is too low, minimum is 1.")
                return
            elif int(n)-1 > 57:
                await ctx.send("Number is too high, maximum is 57.")
                return
            paragraph = bible[int(n)-1]
        em = discord.Embed(title="Reading", description=paragraph)
        em.color = 0x1abc9c
        
        await ctx.send(embed=em)
        
        
        
        f.close()

@bot.command()
async def coinflip(ctx):
  flip = random.choice(range(0,2))
  if flip == 1:
    em = discord.Embed(title="Coin Flip Result", description="You Got Heads!")
    em.color= 0x1abc9c
    await ctx.send(embed=em)
  else:
    em = discord.Embed(title="Coin Flip Result", description="You Got Tails!")
    em.color= 0x1abc9c
    await ctx.send(embed=em)
    
@bot.command(name="8ball")
async def _8ball(ctx, *q): # q = question
    with open("8ball.txt", "r") as f:
        ball = f.readlines()
        f.close()

    if q == None:
        await ctx.send("You did not provide a question")
    else:
        reply = random.choice(ball)
        em = discord.Embed(title="8Ball Results")
        em.color= 0x1abc9c
        em.add_field(name=" ".join(q), value=reply)
        await ctx.send(embed=em)


@bot.command()
async def oof(ctx):
    await ctx.send("You found the secret command! <:WaterBird:845520800458866698>")


@bot.command(aliases=['userinfo'])
async def define(ctx, member: discord.Member):
    roles = member.roles
    whois = discord.Embed(title=member.name + "#" + member.discriminator, description=member.mention, colour=member.colour, timestamp=ctx.message.created_at)
    whois.add_field(name='ID:', value=member.id, inline=False)
    whois.add_field(name="Created Account On:", value=member.created_at.strftime("%a, %#d %B %Y, %I:%M %p UTC"), inline=False)
    whois.add_field(name="Joined Server On:", value=member.joined_at.strftime("%a, %#d %B %Y, %I:%M %p UTC"), inline=False)
    whois.add_field(name='Roles:', value="\n" .join([role.mention for role in roles[1:]]), inline=False)
    whois.add_field(name='Highest Role:',value=member.top_role.mention,inline=False)
    whois.add_field(name='Discriminator:', value=member.discriminator)
    whois.set_author(name=member.name, icon_url=member.avatar_url)
    whois.set_footer(text='Info for ' + member.display_name + '. Requested by ' + ctx.author.name + "#" + ctx.author.discriminator)

    await ctx.send(embed=whois)

@bot.command(description="Shows previous commands requested by this user.")
async def history(ctx, member: discord.Member):
     with open("log.json", "r") as f:
        ball = f.readlines()
        f.close()

@bot.command()
async def troll(ctx, user: discord.Member = None, reason=None):
        if not user or user.id == ctx.author.id:
            await ctx.send(f"**{ctx.author.name}** has started a troll raid!!<:NbaBalls:846314269305602078>")
            return
        if user.id == bot.user.id:
            await ctx.send("<:NbaBalls:846314269305602078> you trolled yourself!!")
            return
        if user.bot:
            await ctx.send(" <:Sadtrollge:849650304747700264> you cannot troll me!!!")
            return

        troll_offer = f"**{user.name}**, you got a secret offer from **{ctx.author.name}**"
        troll_offer = troll_offer + f"\n\n**Reason:** {reason}" if reason else troll_offer
        msg = await ctx.send(troll_offer)

        def reaction_check(m):
            if m.message_id == msg.id and m.user_id == user.id and str(m.emoji) == "✅":
                return True
            return False

        try:
            await msg.add_reaction("✅")
            await bot.wait_for("raw_reaction_add", timeout=30.0, check=reaction_check)
            await msg.edit(content=f"**{user.name}** just got MEGA TROLLED BY **{ctx.author.name}**!!!<:NbaBalls:846314269305602078><:NbaBalls:846314269305602078>")
        except asyncio.TimeoutError:
            await msg.delete()
            await ctx.send(f"well, **{ctx.author.name}** wasn't able to troll {user.name} ;-;")
        except discord.Forbidden:
            # Yeah so, bot doesn't have reaction permission, drop the "offer" word
            troll_offer = f"**{user.name}**, you got trolled by **{ctx.author.name}**!<:NbaBalls:846314269305602078>"
            troll_offer = troll_offer + f"\n\n**Reason:** {reason}" if reason else troll_offer
            await msg.edit(content=troll_offer)


if __name__ == "__main__":
    keep_alive()
    bot.loop.create_task(tasks())
    bot.run(os.getenv("token"))